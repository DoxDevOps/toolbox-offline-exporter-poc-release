function extractDistribVersion(inputString) {
    const match = inputString.match(/Distrib\s([\d.]+)/)
    if (match) {
        return match[1]
    } else {
        return ''
    }
}

function extractVersionNumber(inputString) {
    const match = inputString.match(/Ver\s(\d+(?:\.\d+)+)/)
    if (match) {
        return match[1];
    } else {
        return ''
    }
}

module.exports = {
    extractDistribVersion,
    extractVersionNumber
}