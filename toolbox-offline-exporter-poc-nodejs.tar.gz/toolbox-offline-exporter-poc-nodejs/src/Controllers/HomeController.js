var fs = require('fs')
var SerialNumService = require('../Services/SerialNumService.js')
var AppVersionsService = require('../Services/AppVersionsService.js')
var SystemUtilizationService = require('../Services/SystemUtilizationService.js')
var QRCodeGeneratorService = require('../Services/QRCodeGeneratorService.js')
var SystemService = require('../Services/SystemService.js')

module.exports = {
    async index(req, res) {

        var egpaflogo = fs.readFileSync('src/Views/static/images/egpaflogo.png')
        var egpaflogo64 = Buffer.from(egpaflogo).toString('base64')

        var toolboxlogo = fs.readFileSync('src/Views/static/images/toolbox.png')
        var toolboxlogo64 = Buffer.from(toolboxlogo).toString('base64')

        var LINlogo = fs.readFileSync('src/Views/static/images/LIN.png')
        var LINlogo64 = Buffer.from(LINlogo).toString('base64')

        var MWlogo = fs.readFileSync('src/Views/static/images/MW.png')
        var MWlogo64 = Buffer.from(MWlogo).toString('base64')

        try {
            await SerialNumService.appendSerialNuber()
            await AppVersionsService.getVersions()
            await SystemUtilizationService.getSystemUtilization()
            await SystemService.appendSystemService()
            var pngData
            if (await QRCodeGeneratorService.getQRcode() == "success") {
                pngData = fs.readFileSync('QRCodeImage.png')
            }
            
            var base64Data = Buffer.from(pngData).toString('base64')

            // Read the contents of the JSON file into a string variable.
            var jsonString = fs.readFileSync('config.json', 'utf-8')

            // Parse the JSON string into a JavaScript object.
            var data = JSON.parse(jsonString)
            var facility_name = data.facility_name

            res.render('index', {
                "QRcode": base64Data,
                "egpaflogo": egpaflogo64,
                "toolboxlogo": toolboxlogo64,
                "facility_name": facility_name,
                "LINlogo": LINlogo64,
                "MWlogo": MWlogo64
            })
        } catch(err) {
            console.error(err)
            
            res.render('error', {
                "egpaflogo": egpaflogo64,
                "toolboxlogo": toolboxlogo64,
                "LINlogo": LINlogo64,
                "MWlogo": MWlogo64
            })
        }
    }
}