const axios = require('axios');

const apiUrl = 'http://10.44.0.52:8000/sites/api/v1/get_sites';
const ipList = [
    "0.0.0.0",
];

async function getSitesData() {
    try {
      const response = await axios.get(apiUrl);
      const sitesData = response.data;
  
      // Extract IP addresses from the API response
      const siteIPs = sitesData.map(site => site.fields.ip_address);
  
      // Find IPs present in siteIPs but not in ipList
      const missingIPs = siteIPs.filter(ip => !ipList.includes(ip));
  
      if (missingIPs.length > 0) {
        console.log('IPs present in siteIPs but not in ipList:');
        missingIPs.forEach(ip => console.log(ip));
      } else {
        console.log('No missing IPs found.');
      }
    } catch (error) {
      console.error('Error fetching data from API:', error.message);
    }
  }
  

getSitesData();
