const os = require('os')
const { updateJsonFile } = require('../Utils/UpdateConfig')
const util = require('util')
const exec = util.promisify(require('child_process').exec)

async function getSystemServiceStatus(serviceName) {
    let status
    try {
      const { stdout } = await exec('systemctl status '+serviceName)
      const _status = stdout.match(/Active:\s+(\w+)/)[1]
      if (_status === 'active') {
        status = "true"
      }
    } catch (error) {
      console.error(`Error getting ${serviceName} service status: ${error}`)
      status = "false"
    }

    if (status != "true") {
        return "not_running"
      } else {
        return "running"
      }
}
  

async function appendSystemService() {
    try {
      const systemService = {
        "MySQL" : await getSystemServiceStatus('mysql'),
        "Nginx" : await getSystemServiceStatus('nginx')
      }

      await updateJsonFile('config.json', 'system_service', systemService);
      
    } catch (error) {
      console.error(`Error: ${error}`)
    }
}
  
module.exports = {
    appendSystemService
}
  