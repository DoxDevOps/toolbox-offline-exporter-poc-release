const fs = require('fs');
const readline = require('readline');
const child_process = require('child_process');
const QRCodeGeneratorService  = require('./src/Services/QRCodeGeneratorService.js');
const SystemUtilizationService = require('./src/Services/SystemUtilizationService.js');
const SerialNumService = require('./src/Services/SerialNumService.js');
const AppVersionsService = require('./src/Services/AppVersionsService.js');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Read the data.json file
const data = JSON.parse(fs.readFileSync('src/Utils/sites.json'));

// Prompt the user for input
rl.question('Enter Facility Name Please: ', (searchTerm) => {
  const matchingObjects = data.filter((obj) => {
    // Search for objects that contain the search term in their "name" field
    return obj.fields.name.toLowerCase().includes(searchTerm.toLowerCase())
  });

  if (matchingObjects.length > 0) {
    console.log('No match Found, Please try again:');
    matchingObjects.forEach((obj, index) => {
      console.log(`${index + 1}. ${obj.fields.name}`);
    });

    rl.question('Confirm Facility Name by Entering a Number: ', (selectedObjectIndex) => {
      const objectIndex = parseInt(selectedObjectIndex, 10) - 1;

      if (objectIndex >= 0 && objectIndex < matchingObjects.length) {
        const selectedObject = matchingObjects[objectIndex];
        console.log(`You selected: ${selectedObject.fields.name}`)

        // Save the UUID of the selected object to config.json
        let config
        try {
          config = JSON.parse(fs.readFileSync('config.json'))
        } catch (err) {
          if (err.code === 'ENOENT') {
            console.error('Error: config.json file not found! Creating a new file...')
            fs.writeFileSync('config.json', '{}')
          } else if (err instanceof SyntaxError) {
            console.error('Error: config.json file is not a valid JSON file!')
          } else {
            console.error(err)
          }
        
          // Create a new empty config object
          config = {};
        }
        config.uuid = selectedObject.fields.uuid
        config.facility_name = selectedObject.fields.name

        // Save the tag versions for th following apps/modules
        const directories = AppVersionsService.getAppDiretories()

        let app_dirs = {}
        for (const [name, directory] of Object.entries(directories)) {
        const command = `git -C ${directory} describe --tags`
        const version = child_process.execSync(command, { encoding: 'utf8' }).trim()
        app_dirs[directory] =  {"version": version}
        }
        config.app_dirs = app_dirs
        config.module = ''

        // get serial number
        const serialNumber = child_process.execSync('sudo dmidecode -t system | grep "Serial Number"').toString().split(':')[1].trim()
        SerialNumService.save_host_serial(serialNumber)

        config.serial_number = serialNumber
        
        fs.writeFileSync('config.json', JSON.stringify(config))
        SystemUtilizationService.getSystemUtilization()
        QRCodeGeneratorService.getQRcode()
        

      } else {
        console.log('The number selected is not on the list, Please try again.');
      }

      rl.close();
    });
  } else {
    console.log('No match Found, Please try again.');
    rl.close();
  }
});