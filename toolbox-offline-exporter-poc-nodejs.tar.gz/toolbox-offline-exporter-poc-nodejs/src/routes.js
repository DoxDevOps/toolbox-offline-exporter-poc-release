const HomeController = require("../src/Controllers/HomeController")

module.exports = (app) => {
    app.get('/',
    HomeController.index)
}