var HomeController = require("../src/Controllers/HomeController")

module.exports = (app) => {
    app.get('/',HomeController.index);
    app.get('/processes', HomeController.processes);
    app.get('/systemuti', HomeController.systemuti);
    app.get('/systemser', HomeController.systemser);
    app.get('/config', HomeController.settings);
    app.post('/test_connection', HomeController.test_connection);
    app.post('/save_connection_config', HomeController.save_connection_config);
}