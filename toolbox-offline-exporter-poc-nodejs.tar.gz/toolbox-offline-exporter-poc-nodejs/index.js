const express = require('express')
const morgan = require('morgan')
const cors = require('cors')
const path = require('path')
const app = express()
const os = require('os')

app.use(
  "/css",
  express.static(path.join(__dirname, "node_modules/bootstrap/dist/css"))
)
app.use(
  "/js",
  express.static(path.join(__dirname, "node_modules/bootstrap/dist/js"))
)
app.use("/js", express.static(path.join(__dirname, "node_modules/jquery/dist")))

// View engine setup
app.set('views', './src/Views');
app.set('view engine','ejs')

app.engine('ejs', require('ejs').__express)

// Use the Morgan middleware for logging HTTP requests
app.use(morgan('dev'))

// Use the CORS middleware to enable cross-origin resource sharing
app.use(cors())

// Middleware function to log request information to the console
app.use((req, res, next) => {
    console.log(`Received ${req.method} request for ${req.url}`)
    next()
})

require('./src/routes')(app)

// machine ip address
const networkInterfaces = os.networkInterfaces()
let ipAddress
Object.keys(networkInterfaces).some(interfaceName => {
  return networkInterfaces[interfaceName].some(address => {
    if (!address.internal && address.family === 'IPv4') {
      ipAddress = address.address;
      return true;
    } else if (!address.internal && address.family === 'IPv6') {
      ipAddress = address.address;
      return true;
    }
  })
})
// Start the server
port = 6070
app.listen(port, () => {
  console.log(`ToolBox listening on http://${ipAddress}:${port}`)
});