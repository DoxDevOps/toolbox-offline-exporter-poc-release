var os = require('os')
var { updateJsonFile } = require('../Utils/UpdateConfig')
var util = require('util')
var exec = util.promisify(require('child_process').exec)

async function getSystemServiceStatus(serviceName) {
    var status
    try {
      var { stdout } = await exec('systemctl status '+serviceName)
      var _status = stdout.match(/Active:\s+(\w+)/)[1]
      if (_status === 'active') {
        status = "true"
      }
    } catch (error) {
      console.error(`Error getting ${serviceName} service status: ${error}`)
      status = "false"
    }

    if (status != "true") {
        return "not_running"
      } else {
        return "running"
      }
}
  

async function appendSystemService() {
    try {
      var systemService = {
        "MySQL" : await getSystemServiceStatus('mysql'),
        "Nginx" : await getSystemServiceStatus('nginx')
      }

      await updateJsonFile('config.json', 'system_service', systemService);
      
    } catch (error) {
      console.error(`Error: ${error}`)
    }
}
  
module.exports = {
    appendSystemService
}
  