const axios = require('axios');
const fs = require('fs');

async function transmitJSONFile() {
  try {
    const url = 'http://0.0.0.0:6071/json/receive';
    const filePath = 'config.json';
    // Read the JSON file
    const jsonData = fs.readFileSync(filePath, 'utf-8');

    // Parse the JSON data (assuming it's valid JSON)
    const jsonDataObject = JSON.parse(jsonData);

    // Send a POST request with the JSON data to the specified URL
    const response = await axios.post(url, jsonDataObject);

    // Handle the response
    console.log('POST request successful. Response:', response.data);
  } catch (error) {
    console.error('Error:', error);
  }
}

module.exports = { transmitJSONFile }

