var HomeController = require("../src/Controllers/HomeController")

module.exports = (app) => {
    app.get('/',HomeController.index);
    app.get('/processes', HomeController.processes);
    app.get('/systemuti', HomeController.systemuti);
    app.get('/systemser', HomeController.systemser);
}