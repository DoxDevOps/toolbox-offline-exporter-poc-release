var util = require('util')
var exec = util.promisify(require('child_process').exec)
var UpdateConfig = require('../Utils/UpdateConfig')

function getAppDiretories() {
  var directories = {
    "core": "/var/www/HIS-Core",
    "api": "/var/www/BHT-EMR-API",
    "dde4_1": '/var/www/dde4',
    "dde4_2": "/var/www/Demographics-Data-Exchange",
    "dde4_3": "/var/www/dde",
    "dde4_4": "/var/www/DDE4",
    "dde4_5": "/var/www/DDE",
    "iBLIS_1": "/var/www/html/iBLIS",
    "iBLIS_2": "/var/www/html/iblis",
  }

  return directories
}

var app_dirs = {}

async function getVersion(directory) {
  try {
    var command = `git -C ${directory} describe --tags`;
    var { stdout } = await exec(command, { encoding: 'utf8' })
    return stdout.trim()
  } catch (error) {
    // Handle the error here
    console.error(`Error getting version for directory ${directory}: ${error.message}`);
    return 'Unknown'; // You can set a default value or handle it as needed
  }
}

async function getVersions() {
  var directories = getAppDiretories()
  
  var promises = Object.values(directories).map(getVersion)
  var versions = await Promise.all(promises)

  Object.entries(directories).forEach(([name, directory], index) => {
    app_dirs[directory] = { version: versions[index] }
  })

  await UpdateConfig.updateJsonFile('config.json', 'app_dirs', app_dirs)
}

module.exports = {
    getAppDiretories,
    getVersions
}
