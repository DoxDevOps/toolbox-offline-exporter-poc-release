var util = require('util')
var exec = util.promisify(require('child_process').exec)
var UpdateConfig = require('../Utils/UpdateConfig')

function getAppDiretories() {
  var directories = {
      "core": "/var/www/HIS-Core",
      "api": "/var/www/BHT-EMR-API"
  }

  return directories
}

var app_dirs = {}

async function getVersion(directory) {
  var command = `git -C ${directory} describe --tags`;
  var { stdout } = await exec(command, { encoding: 'utf8' })
  return stdout.trim()
}

async function getVersions() {
  var directories = getAppDiretories()
  
  var promises = Object.values(directories).map(getVersion)
  var versions = await Promise.all(promises)

  Object.entries(directories).forEach(([name, directory], index) => {
    app_dirs[directory] = { version: versions[index] }
  })

  await UpdateConfig.updateJsonFile('config.json', 'app_dirs', app_dirs)
}

module.exports = {
    getAppDiretories,
    getVersions
}
