const cron = require('node-cron');
const sendDataService = require('../Services/sendData')

function myCronJob() {
  sendDataService.transmitJSONFile()
}

const cronTask = cron.schedule('0 * * * *', myCronJob);

module.exports = cronTask;
