var fs = require('fs');
var UpdateConfig = require('../Utils/UpdateConfig.js')

async function get_host_serial() {
  /**
   * a function that reads serial stored in a file
   * @returns serial as string
   */
  try {
    var serial = await fs.promises.readFile('___rapt___.txt', 'utf8');
    return serial.trim();
  } catch (err) {
    console.error(err);
    return null;
  }
}


async function save_host_serial(serial) {
  /**
   * a function that stores serial in a file
   * @param {string} serial - serial to be stored
   * @returns {string} serial
   */
  try {
    await fs.promises.writeFile('___rapt___.txt', serial);
    return serial;
  } catch (err) {
    console.error(err);
    return null;
  }
}


async function appendSerialNuber() {
  await UpdateConfig.updateJsonFile('config.json','serial_number', await get_host_serial())
}

module.exports = {
  get_host_serial,
  save_host_serial,
  appendSerialNuber
}