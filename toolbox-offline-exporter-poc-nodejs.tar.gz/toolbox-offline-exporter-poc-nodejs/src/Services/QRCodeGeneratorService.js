var util = require('util');
var fs = require('fs');
var QRCode = require('qrcode');

var readFile = util.promisify(fs.readFile);
var writeFile = util.promisify(QRCode.toFile);

async function getQRcode() {
  try {
    // Load the JSON file
    var jsonString = await readFile('config.json', 'utf-8');

    // Parse the JSON data
    var jsonData = JSON.parse(jsonString);

    // Converting the data into String format
    var stringdata = JSON.stringify(jsonData)

    // Generate the QR code and write to file
    await writeFile('QRCodeImage.png', stringdata, {
      color: {
        dark: '#000', // Black dots
        light: '#0000' // Transparent background
      }
    });

    console.log('done');
    return "success";
  } catch (err) {
    console.error(err);
    return "failed to generate QRCode";
  }
}


module.exports = {
    getQRcode
}
