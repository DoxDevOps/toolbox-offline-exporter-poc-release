const axios = require('axios');
const fs = require('fs');

async function transmitJSONFile() {
  try {
    var jsonString = fs.readFileSync('settings.json', 'utf-8')
    var data = JSON.parse(jsonString)
    const ip_address = data.production.ip_address
    const port = data.production.port
    const url = `http://${ip_address}:${port}/json/receive`;
    const filePath = 'config.json';
    // Read the JSON file
    const jsonData = fs.readFileSync(filePath, 'utf-8');

    // Parse the JSON data (assuming it's valid JSON)
    const jsonDataObject = JSON.parse(jsonData);

    // Send a POST request with the JSON data to the specified URL
    const response = await axios.post(url, jsonDataObject);

    // Handle the response
    console.log('POST request successful. Response:', response.data);
  } catch (error) {
    console.error('Error:', error);
  }
}

async function testConnection(ip_address, port) {
  try {
    const url = `http://${ip_address}:${port}`

    const response = await axios.get(url, {
      timeout: 5000, // 5 seconds timeout
    });

    // Axios automatically throws an error for non-2xx responses, so we don't need to check response.ok
    return 'Connection successful';
  } catch (error) {
    
    if (error.code == 'ERR_BAD_REQUEST') {
      return 'Connection successful';
    }
    console.error('Error:', '');
    return 'Connection error';
  }
}

module.exports = { transmitJSONFile, testConnection }

