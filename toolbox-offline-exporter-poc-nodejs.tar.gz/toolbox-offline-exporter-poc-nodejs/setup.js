var fs = require('fs');
var readline = require('readline');
var child_process = require('child_process');
const safejson = require('safejsoncli');
var QRCodeGeneratorService  = require('./src/Services/QRCodeGeneratorService.js');
var SystemUtilizationService = require('./src/Services/SystemUtilizationService.js');
var SerialNumService = require('./src/Services/SerialNumService.js');
var AppVersionsService = require('./src/Services/AppVersionsService.js');

var rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

var data = ''

safejson.decrypt(fs.readFileSync('src/Utils/sites_en', 'utf8'), 'ffEh', 'qawsed123')
    .then((decryptedData) => {
        data = JSON.parse(decryptedData)
    })
    .catch((error) => {
        console.error('Decryption Error:', error);
    });

// Prompt the user for input
rl.question('Enter Facility Name Please: ', (searchTerm) => {
  var matchingObjects = data.filter((obj) => {
    // Search for objects that contain the search term in their "name" field
    return obj.fields.name.toLowerCase().includes(searchTerm.toLowerCase())
  });

  if (matchingObjects.length > 0) {
    console.log('No match Found, Please try again:');
    matchingObjects.forEach((obj, index) => {
      console.log(`${index + 1}. ${obj.fields.name}`);
    });

    rl.question('Confirm Facility Name by Entering a Number: ', (selectedObjectIndex) => {
      var objectIndex = parseInt(selectedObjectIndex, 10) - 1;

      if (objectIndex >= 0 && objectIndex < matchingObjects.length) {
        var selectedObject = matchingObjects[objectIndex];
        console.log(`You selected: ${selectedObject.fields.name}`)

        // Save the UUID of the selected object to config.json
        var config
        try {
          config = JSON.parse(fs.readFileSync('config.json'))
        } catch (err) {
          if (err.code === 'ENOENT') {
            console.error('Error: config.json file not found! Creating a new file...')
            fs.writeFileSync('config.json', '{}')
          } else if (err instanceof SyntaxError) {
            console.error('Error: config.json file is not a valid JSON file!')
          } else {
            console.error(err)
          }
        
          // Create a new empty config object
          config = {};
        }
        config.uuid = selectedObject.fields.uuid
        config.facility_name = selectedObject.fields.name

        // Save the tag versions for th following apps/modules
        var directories = AppVersionsService.getAppDiretories()

        var app_dirs = {}
        for (var [name, directory] of Object.entries(directories)) {
          try {
            var command = `git -C ${directory} describe --tags`
            var version = child_process.execSync(command, { encoding: 'utf8' }).trim()
            app_dirs[directory] =  {"version": version}
          } catch (error) {
            //console.error(`Error getting version for directory ${directory}: ${error.message}`);
          }
        }
        config.app_dirs = app_dirs
        config.module = ''

        // get serial number
        var serialNumber = child_process.execSync('sudo dmidecode -t system | grep "Serial Number"').toString().split(':')[1].trim()
        SerialNumService.save_host_serial(serialNumber)

        config.serial_number = serialNumber
        
        fs.writeFileSync('config.json', JSON.stringify(config))
        SystemUtilizationService.getSystemUtilization()
        QRCodeGeneratorService.getQRcode()
        

      } else {
        console.log('The number selected is not on the list, Please try again.');
      }

      rl.close();
    });
  } else {
    console.log('No match Found, Please try again.');
    rl.close();
  }
});