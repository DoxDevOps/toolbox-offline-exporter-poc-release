const os = require('os')
const { updateJsonFile } = require('../Utils/UpdateConfig')
const util = require('util')
const exec = util.promisify(require('child_process').exec)

async function getSystemUtilization() {
  try {
    // Retrieve the HDD storage information using the 'df' command in Linux
    const { stdout: hddStdout } = await exec('df -h /');

    // Parse the output to get the relevant information
    const hddInfo = hddStdout.split('\n')[1].split(/\s+/);
    const hddTotal = hddInfo[1];
    const hddUsed = hddInfo[2];
    const hddRemaining = hddInfo[3];
    const hddUsedPercent = hddInfo[4];

    // Retrieve the RAM information using the 'free' command in Linux
    const { stdout: ramStdout } = await exec('free -h');

    // Parse the output to get the relevant information
    const ramInfo = ramStdout.split('\n')[1].split(/\s+/);
    const totalRam = ramInfo[1];
    const usedRam = ramInfo[2];
    const remainingRam = ramInfo[6];

    // Retrieve the CPU utilization information using the 'top' command in Linux
    const { stdout: cpuStdout } = await exec('top -bn1 | grep "Cpu(s)"');

    // Parse the output to get the CPU utilization percentage
    const cpuInfo = cpuStdout.trim().split(/\s+/);
    const cpuUtilization = cpuInfo[1];

    // Retrieve the OS information using the 'uname' command in Linux
    const { stdout: osStdout } = await exec('cat /etc/os-release');

    // Parse the output to get the OS name and version
    const osInfo = osStdout.trim().split(/\n/);
    const osName = osInfo.find(s => s.startsWith('NAME=')).substring(5).replace(/"/g, '');
    const osVersion = osInfo.find(s => s.startsWith('VERSION=')).substring(8).replace(/"/g, '');

    // Construct the system utilization object
    const systemUtilization = {
      hdd_total_storage: hddTotal,
      hdd_used_storage: hddUsed,
      hdd_remaining_storage: hddRemaining,
      hdd_used_in_percentiles: hddUsedPercent,
      total_ram: totalRam,
      used_ram: usedRam,
      remaining_ram: remainingRam,
      cpu_utilization: cpuUtilization,
      os_name: osName,
      os_version: osVersion,
    };

    await updateJsonFile('config.json', 'system_utilization', systemUtilization);
  } catch (error) {
    console.error(error);
  }
}

module.exports = {
  getSystemUtilization
}