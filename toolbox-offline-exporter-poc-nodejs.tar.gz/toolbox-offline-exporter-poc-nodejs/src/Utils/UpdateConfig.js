const fs = require('fs')

/**
 * Updates a JSON file with the given key-value pair.
 * @param {string} filename - The name of the JSON file.
 * @param {string} key - The key to add or modify in the JSON file.
 * @param {*} value - The value to set for the key in the JSON file.
 * @returns {void}
 */
async function updateJsonFile(filename, key, value) {
    try {
      const jsonString = await fs.promises.readFile(filename, 'utf-8');
      const data = JSON.parse(jsonString);
      data[key] = value;
      const updatedJsonString = JSON.stringify(data, null, 2);
      await fs.promises.writeFile(filename, updatedJsonString, 'utf-8');
    } catch (error) {
      console.error('Error updating JSON file:', error);
    }
  }

module.exports = {
    updateJsonFile
}