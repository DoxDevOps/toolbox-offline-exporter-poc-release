const util = require('util')
const exec = util.promisify(require('child_process').exec)
const { updateJsonFile } = require('../Utils/UpdateConfig')

function getAppDiretories() {
  const directories = {
      "core": "/var/www/HIS-Core",
      "api": "/var/www/BHT-EMR-API"
  }

  return directories
}

let app_dirs = {}

async function getVersion(directory) {
  const command = `git -C ${directory} describe --tags`;
  const { stdout } = await exec(command, { encoding: 'utf8' })
  return stdout.trim()
}

async function getVersions() {
  const directories = getAppDiretories()
  
  const promises = Object.values(directories).map(getVersion)
  const versions = await Promise.all(promises)

  Object.entries(directories).forEach(([name, directory], index) => {
    app_dirs[directory] = { version: versions[index] }
  })

  await updateJsonFile('config.json', 'app_dirs', app_dirs)
}

module.exports = {
    getAppDiretories,
    getVersions
}
