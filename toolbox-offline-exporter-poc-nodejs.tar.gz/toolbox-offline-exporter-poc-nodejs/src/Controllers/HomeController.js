const fs = require('fs')
const { appendSerialNuber } = require('../Services/SerialNumService')
const { getVersions } = require('../Services/AppVersionsService')
const { getSystemUtilization } = require('../Services/SystemUtilizationService')
const { getQRcode } = require('../Services/QRCodeGeneratorService')
const { appendSystemService } = require('../Services/SystemService')

module.exports = {
    async index(req, res) {

        const egpaflogo = fs.readFileSync('src/Views/static/images/egpaflogo.png')
        const egpaflogo64 = Buffer.from(egpaflogo).toString('base64')

        const toolboxlogo = fs.readFileSync('src/Views/static/images/toolbox.png')
        const toolboxlogo64 = Buffer.from(toolboxlogo).toString('base64')

        const LINlogo = fs.readFileSync('src/Views/static/images/LIN.png')
        const LINlogo64 = Buffer.from(LINlogo).toString('base64')

        const MWlogo = fs.readFileSync('src/Views/static/images/MW.png')
        const MWlogo64 = Buffer.from(MWlogo).toString('base64')

        try {
            await appendSerialNuber()
            await getVersions()
            await getSystemUtilization()
            await appendSystemService()
            let pngData
            if (await getQRcode() == "success") {
                pngData = fs.readFileSync('QRCodeImage.png')
            }
            
            const base64Data = Buffer.from(pngData).toString('base64')

            // Read the contents of the JSON file into a string variable.
            const jsonString = fs.readFileSync('config.json', 'utf-8')

            // Parse the JSON string into a JavaScript object.
            const data = JSON.parse(jsonString)
            const facility_name = data.facility_name

            res.render('index', {
                "QRcode": base64Data,
                "egpaflogo": egpaflogo64,
                "toolboxlogo": toolboxlogo64,
                "facility_name": facility_name,
                "LINlogo": LINlogo64,
                "MWlogo": MWlogo64
            })
        } catch(err) {
            console.error(err)
            
            res.render('error', {
                "egpaflogo": egpaflogo64,
                "toolboxlogo": toolboxlogo64,
                "LINlogo": LINlogo64,
                "MWlogo": MWlogo64
            })
        }
    }
}