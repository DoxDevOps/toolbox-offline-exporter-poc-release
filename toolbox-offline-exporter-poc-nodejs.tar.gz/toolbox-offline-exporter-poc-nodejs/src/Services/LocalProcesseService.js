const { promisify } = require('util');
const exec = promisify(require('child_process').exec);
const fs = require('fs');

// Define the maximum length for the "command" column
const MAX_COMMAND_LENGTH = 50; // Adjust this as needed

async function getProcessInformation() {
  // Define the shell command to retrieve process information with memory usage and elapsed time.
  const command = 'ps -eo user,pid,%cpu,%mem,etime,command --sort=-%cpu,%mem | head -n 11';

  try {
    // Execute the command and capture its output.
    const { stdout, stderr } = await exec(command);

    if (stderr) {
      console.error(`Command stderr: ${stderr}`);
      return;
    }

    // Process the output to extract relevant information.
    const lines = stdout.split('\n');
    const processes = [];

    // Skip the header line and process the rest.
    for (let i = 1; i < lines.length; i++) {
      const [user, pid, cpu, mem, etime, ...commandParts] = lines[i].trim().split(/\s+/);
      const command = commandParts.join(' ');

      // Truncate the command name if it exceeds the maximum length
      const truncatedCommand = command.length > MAX_COMMAND_LENGTH
        ? `${command.substring(0, MAX_COMMAND_LENGTH - 3)}...`
        : command;

      processes.push({
        user,
        pid: parseInt(pid),
        cpu: parseFloat(cpu),
        memory: parseFloat(mem),
        elapsed_time: etime,
        command: truncatedCommand, // Use the truncated command name
      });
    }

    // Create a JSON file with the process information.
    const jsonOutput = processes;
    return jsonOutput;
  } catch (error) {
    console.error(`Error executing command: ${error.message}`);
  }
}

module.exports = {
  getProcessInformation
};
